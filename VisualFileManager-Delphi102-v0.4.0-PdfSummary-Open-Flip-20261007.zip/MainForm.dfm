object FrmVisualFileManager: TFrmVisualFileManager
  Left = 0
  Top = 0
  Caption = 'Konusal Dosya Y'#246'neticisi'
  ClientHeight = 760
  ClientWidth = 1200
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 13
end
